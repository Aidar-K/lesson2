package com.company;

public class Main {
    public static String classic() {
        int age = 30;
        int temp = 15;

        if (age > 20 && age < 45 && temp > -20 && temp > 30) {
            return ("Можно идти гулять");
        }
        if (age < 20 && temp > 0 && temp < 28) {
            return ("Можно идти гулять");
        }
        if (age > 45 && temp < -10 && temp < 25) {
            return ("Можно идти гулять");
        } else {
            return ("Оставайтесь дома");
        }
    }

    public static void main(String[] args) {
        classic();
        classic();
        classic();
        classic();
        classic();
    }
}
